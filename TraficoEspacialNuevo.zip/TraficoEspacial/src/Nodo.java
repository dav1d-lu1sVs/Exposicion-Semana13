public class Nodo {
    public String destino;
    public int peso;

    public Nodo(String destino, int peso) {
        this.destino = destino;
        this.peso = peso;
    }
}
