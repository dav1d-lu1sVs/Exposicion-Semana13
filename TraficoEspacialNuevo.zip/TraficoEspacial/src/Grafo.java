import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.util.List;

public class Grafo extends JPanel {

    public final Map<String, Point> posiciones = new HashMap<>();
    public final Map<String, List<Nodo>> grafo;

    public Grafo(Map<String, List<Nodo>> grafo) {
        this.grafo = grafo;
        posiciones();
        setPreferredSize(new Dimension(600, 400));
        setBackground(Color.BLACK);
        setOpaque(true);
    }

    private void posiciones() {
        posiciones.put("Tierra", new Point(90, 200));
        posiciones.put("Orbita Terrestre Alta", new Point(300, 50));
        posiciones.put("Luna", new Point(450, 200));
        posiciones.put("Base Lunar", new Point(500, 300));
        posiciones.put("Base Orbital", new Point(100, 100));
        posiciones.put("Estacion Espacial Internacional", new Point(200, 350));
        posiciones.put("Satelite Sputnik", new Point(300, 310));
        posiciones.put("Voyager 1", new Point(600, 100));
        posiciones.put("Antena 1", new Point(230, 160));


    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(Color.WHITE);
        g2.setStroke(new BasicStroke(2));

        for (Map.Entry<String, List<Nodo>> entry : grafo.entrySet()) {
            String origen = entry.getKey();
            Point p1 = posiciones.get(origen);
            if (p1 == null) continue;

            for (Nodo arista : entry.getValue()) {
                Point p2 = posiciones.get(arista.destino);
                if (p2 == null) continue;

                g2.drawLine(p1.x, p1.y, p2.x, p2.y);
                int midX = (p1.x + p2.x) / 2;
                int midY = (p1.y + p2.y) / 2;
                g2.drawString(String.valueOf(arista.peso), midX, midY);
            }
        }

        for (String nodo : posiciones.keySet()) {
            Point p = posiciones.get(nodo);
            dibujarNodo(g2, nodo, p);
        }
    }

    private void dibujarNodo(Graphics2D g2, String nodo, Point p) {
        int size = 30;
        if (nodo.equals("Tierra")) size = 50;
        else if (nodo.equals("Luna")) size = 40;

        g2.setColor(Color.CYAN);
        g2.fillOval(p.x - size / 2, p.y - size / 2, size, size);

        g2.setColor(Color.WHITE);
        FontMetrics fm = g2.getFontMetrics();
        int textWidth = fm.stringWidth(nodo);
        g2.drawString(nodo, p.x - textWidth / 2, p.y - size / 2 - 5);
    }
    }

