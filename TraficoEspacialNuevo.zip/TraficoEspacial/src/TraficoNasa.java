import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.util.List;

public class TraficoNasa {
    private JPanel PGeneral;
    private JPanel DibujarGrafo;
    private JButton encontrarMejorRutaButton;
    private JComboBox Destino;
    private JComboBox Origen;
    private JLabel OrigenIngresar;
    private JComboBox OrigenIng;
    private JTextField textNodonuevo;
    private JLabel NodoNuevo;
    private JTextField textPeso;
    private JButton ingresarNuevoNodoButton;
    private JLabel PesoNuevo;
    private JTextField textX;
    private JTextField textY;
    private JLabel PosiscionY;
    private JLabel PosiscionX;

    public static Map<String, List<Nodo>> grafo = new HashMap<>();
    private Grafo dibujo;
    public TraficoNasa() {
        inicializarGrafo();

        dibujo = new Grafo(grafo);
        DibujarGrafo.setLayout(new BorderLayout());
        DibujarGrafo.add(dibujo, BorderLayout.CENTER);
        encontrarMejorRutaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String inicio = (String) Origen.getSelectedItem();
                String fin = (String) Destino.getSelectedItem();

                if (inicio == null || fin == null) {
                    JOptionPane.showMessageDialog(PGeneral, "Por favor selecciona nodo origen y destino.");
                    return;
                }

                if (inicio.equals(fin)) {
                    JOptionPane.showMessageDialog(PGeneral, "El nodo origen y destino no pueden ser iguales.");
                    return;
                }

                List<String> ruta = dijkstra(grafo, inicio, fin);

                if (ruta.isEmpty()) {
                    JOptionPane.showMessageDialog(PGeneral, "No existe ruta entre " + inicio + " y " + fin);
                } else {
                    int pesoTotal = 0;
                    for (int i = 0; i < ruta.size() - 1; i++) {
                        String actual = ruta.get(i);
                        String siguiente = ruta.get(i + 1);
                        for (Nodo arista : grafo.get(actual)) {
                            if (arista.destino.equals(siguiente)) {
                                pesoTotal += arista.peso;
                                break;
                            }
                        }
                    }

                    JOptionPane.showMessageDialog(PGeneral,"Ruta más corta:\n" + String.join(" - ", ruta) + "\nPeso total: " + pesoTotal);

                }
            }


        });
        ingresarNuevoNodoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                    String nombreNuevoNodo = textNodonuevo.getText().trim();
                    String origen = (String) OrigenIng.getSelectedItem();
                    String pesoStr = textPeso.getText().trim();
                    String xStr = textX.getText().trim();
                    String yStr = textY.getText().trim();

                    if (nombreNuevoNodo.isEmpty() || origen == null || pesoStr.isEmpty() || xStr.isEmpty() || yStr.isEmpty()) {
                        JOptionPane.showMessageDialog(PGeneral, "Por favor llena todos los campos.");
                        return;
                    }

                    if (grafo.containsKey(nombreNuevoNodo)) {
                        JOptionPane.showMessageDialog(PGeneral, "Ese nodo ya existe.");
                        return;
                    }

                    int peso;
                    int x, y;
                    try {
                        peso = Integer.parseInt(pesoStr);
                        x = Integer.parseInt(xStr);
                        y = Integer.parseInt(yStr);
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(PGeneral, "Peso y coordenadas deben ser números válidos.");
                        return;
                    }

                    // Agrega el nuevo nodo a posiciones
                    dibujo.posiciones.put(nombreNuevoNodo, new Point(x, y));

                    // Agrega las aristas bidireccionales
                    arista(origen, nombreNuevoNodo, peso);

                    // Actualiza los ComboBox
                    Origen.addItem(nombreNuevoNodo);
                    Destino.addItem(nombreNuevoNodo);
                    OrigenIng.addItem(nombreNuevoNodo);

                    // Redibuja el panel
                    dibujo.repaint();

                    // Limpia los campos
                    textNodonuevo.setText("");
                    textPeso.setText("");
                    textX.setText("");
                    textY.setText("");

                    JOptionPane.showMessageDialog(PGeneral, "Nodo y arista agregados con éxito.");
                }

        });
    }

    private void inicializarGrafo() {
        arista("Tierra", "Base Orbital", 50);
        arista("Tierra", "Orbita Terrestre Alta", 100);
        arista("Tierra", "Antena 1", 100);
        arista("Antena 1", "Voyager 1", 1000);
        arista("Antena 1", "Satelite Sputnik", 150);
        arista("Orbita Terrestre Alta", "Luna", 80);
        arista("Tierra", "Luna", 200);
        arista("Estacion Espacial Internacional", "Tierra", 200);
        arista("Luna", "Satelite Geoestacionario", 25);
        arista("Luna", "Base Lunar", 60);
        arista("Luna", "Voyager 1", 500);
        arista("Satelite Sputnik", "Base Lunar", 75);
        arista("Satelite Sputnik", "Base Orbital", 100);

    }

    private void arista(String origen, String destino, int peso) {
        grafo.putIfAbsent(origen, new ArrayList<>());
        grafo.get(origen).add(new Nodo(destino, peso));
        grafo.putIfAbsent(destino, new ArrayList<>());
        grafo.get(destino).add(new Nodo(origen, peso));
    }

    public static List<String> dijkstra(Map<String, List<Nodo>> grafo, String inicio, String fin) {
        Map<String, Integer> distancias = new HashMap<>();
        Map<String, String> predecesores = new HashMap<>();
        PriorityQueue<String> queue = new PriorityQueue<>(Comparator.comparingInt(distancias::get));

        for (String nodo : grafo.keySet()) {
            distancias.put(nodo, Integer.MAX_VALUE);
        }
        distancias.put(inicio, 0);
        queue.offer(inicio);

        while (!queue.isEmpty()) {
            String actual = queue.poll();
            if (actual.equals(fin)) break;

            for (Nodo vecino : grafo.getOrDefault(actual, new ArrayList<>())) {
                int nuevoPeso = distancias.get(actual) + vecino.peso;
                if (nuevoPeso < distancias.get(vecino.destino)) {
                    distancias.put(vecino.destino, nuevoPeso);
                    predecesores.put(vecino.destino, actual);
                    queue.offer(vecino.destino);
                }
            }
        }

        LinkedList<String> ruta = new LinkedList<>();
        String paso = fin;
        while (paso != null) {
            ruta.addFirst(paso);
            paso = predecesores.get(paso);
        }

        if (!ruta.isEmpty() && ruta.getFirst().equals(inicio)) {
            return ruta;
        } else {
            return Collections.emptyList();
        }
    }


    public static void main(String[] args) {
        JFrame frame = new JFrame("TraficoNasa");
        frame.setContentPane(new TraficoNasa().PGeneral);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}

